package org.example;

public class NoSuchTypeOfBottleException extends RuntimeException {
}
