package org.example;

public enum BottleMaterial {
    PLASTIC, GLASS;
}
