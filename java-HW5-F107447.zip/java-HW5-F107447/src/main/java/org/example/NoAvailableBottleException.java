package org.example;

public class NoAvailableBottleException extends RuntimeException {
}
